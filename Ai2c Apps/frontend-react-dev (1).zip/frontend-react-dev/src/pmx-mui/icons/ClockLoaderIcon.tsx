import React from 'react';

import { SvgIcon, useTheme } from '@mui/material';

import { IconProps } from '../models';

/**
 * ClockLoaderIcon component.
 *
 * @component
 * @example
 * ```tsx
 * <ClockLoaderIcon size={24} fill="red" />
 * ```
 */
export const ClockLoaderIcon: React.FC<IconProps> = (props) => {
  const theme = useTheme();
  const { size, height = size || '25', width = size || '25', fill = theme.palette.text.primary, sx } = props;

  return (
    <SvgIcon
      sx={{
        ...sx,
        height,
        width,
      }}
    >
      <svg
        data-icon="clock-loader"
        data-prefix="pmx"
        width={width}
        height={height}
        viewBox="0 0 20 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M10 20C8.61667 20 7.31667 19.7375 6.1 19.2125C4.88333 18.6875 3.825 17.975 2.925 17.075C2.025 16.175 1.3125 15.1167 0.7875 13.9C0.2625 12.6833 0 11.3833 0 10C0 8.61667 0.2625 7.31667 0.7875 6.1C1.3125 4.88333 2.025 3.825 2.925 2.925C3.825 2.025 4.88333 1.3125 6.1 0.7875C7.31667 0.2625 8.61667 0 10 0C11.3833 0 12.6833 0.2625 13.9 0.7875C15.1167 1.3125 16.175 2.025 17.075 2.925C17.975 3.825 18.6875 4.88333 19.2125 6.1C19.7375 7.31667 20 8.61667 20 10C20 11.3833 19.7375 12.6833 19.2125 13.9C18.6875 15.1167 17.975 16.175 17.075 17.075C16.175 17.975 15.1167 18.6875 13.9 19.2125C12.6833 19.7375 11.3833 20 10 20ZM4.325 15.675L10 10V2C7.76667 2 5.875 2.775 4.325 4.325C2.775 5.875 2 7.76667 2 10C2 11.0667 2.2 12.0917 2.6 13.075C3 14.0583 3.575 14.925 4.325 15.675Z"
          fill={fill}
        />
      </svg>
    </SvgIcon>
  );
};
