export * from './soldierManagerApi';
