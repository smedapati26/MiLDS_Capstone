export * from './soldierApi';
