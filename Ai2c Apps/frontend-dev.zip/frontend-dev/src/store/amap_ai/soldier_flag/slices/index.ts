export * from './soldierFlagApi';
